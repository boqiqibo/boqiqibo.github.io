# CVSS v4.0 计算器

Deployed: <https://cvss.xc1ym.com>

翻译自: <https://github.com/RedHatProductSecurity/cvss-v4-calculator>
